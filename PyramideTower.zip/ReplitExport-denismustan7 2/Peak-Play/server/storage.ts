import { db } from "./db";
import { games, results, type Game, type Result, type GameState, type Player } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Database operations
  createGame(roomId: string): Promise<Game>;
  getGame(roomId: string): Promise<Game | undefined>;
  saveResult(result: typeof results.$inferInsert): Promise<Result>;
  
  // In-memory Game State operations
  getGameState(roomId: string): GameState | undefined;
  createGameState(roomId: string): GameState;
  addPlayer(roomId: string, player: Player): void;
  updatePlayer(roomId: string, playerId: string, updates: Partial<Player>): void;
  removePlayer(roomId: string, playerId: string): void;
  updateGameStatus(roomId: string, status: 'waiting' | 'playing' | 'ended'): void;
  getAllActiveRooms(): GameState[];
}

export class MemStorage implements IStorage {
  private activeGames: Map<string, GameState>;

  constructor() {
    this.activeGames = new Map();
  }

  // DB Methods
  async createGame(roomId: string): Promise<Game> {
    const [game] = await db.insert(games).values({ roomCode: roomId, status: 'waiting' }).returning();
    return game;
  }

  async getGame(roomId: string): Promise<Game | undefined> {
    // For MVP we mostly use in-memory state, but this supports persistence check
    const [game] = await db.select().from(games).where(eq(games.roomCode, roomId));
    return game;
  }

  async saveResult(result: typeof results.$inferInsert): Promise<Result> {
    const [saved] = await db.insert(results).values(result).returning();
    return saved;
  }

  // Memory Methods
  getGameState(roomId: string): GameState | undefined {
    return this.activeGames.get(roomId);
  }

  createGameState(roomId: string): GameState {
    const state: GameState = {
      roomId,
      status: 'waiting',
      players: []
    };
    this.activeGames.set(roomId, state);
    return state;
  }

  addPlayer(roomId: string, player: Player): void {
    const state = this.getGameState(roomId);
    if (state) {
      // Prevent duplicates
      if (!state.players.find(p => p.id === player.id)) {
        state.players.push(player);
      } else {
        // Reconnect
        const existing = state.players.find(p => p.id === player.id)!;
        existing.isConnected = true;
      }
    }
  }

  updatePlayer(roomId: string, playerId: string, updates: Partial<Player>): void {
    const state = this.getGameState(roomId);
    if (state) {
      const player = state.players.find(p => p.id === playerId);
      if (player) {
        Object.assign(player, updates);
      }
    }
  }

  removePlayer(roomId: string, playerId: string): void {
    const state = this.getGameState(roomId);
    if (state) {
      const player = state.players.find(p => p.id === playerId);
      if (player) {
        player.isConnected = false;
        // We don't remove immediately to allow reconnects, or for score tracking
      }
    }
  }

  updateGameStatus(roomId: string, status: 'waiting' | 'playing' | 'ended'): void {
    const state = this.getGameState(roomId);
    if (state) {
      state.status = status;
    }
  }

  getAllActiveRooms(): GameState[] {
    return Array.from(this.activeGames.values());
  }
}

export const storage = new MemStorage();
