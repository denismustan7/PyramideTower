## Packages
framer-motion | Essential for smooth card animations and transitions
canvas-confetti | Celebration effects for winning
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely
socket.io-client | Client-side socket.io integration

## Notes
WebSocket connects via socket.io at /socket.io
Game logic: Tri-Peaks rules implemented client-side for immediate feedback, synced via socket.io
Card assets: CSS-only implementation for performance and crispness
