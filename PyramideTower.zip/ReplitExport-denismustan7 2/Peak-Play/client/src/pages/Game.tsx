import { useEffect, useState, useMemo } from 'react';
import { useRoute, useLocation } from "wouter";
import { useGameSocket } from '@/hooks/use-game-socket';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { GameHeader, GameOverModal } from "@/components/GameUI";
import { PlayingCard } from "@/components/PlayingCard";
import { motion, AnimatePresence } from "framer-motion";
import confetti from "canvas-confetti";
import { Share2, ArrowRight } from "lucide-react";
import type { Card as CardType } from "@shared/schema";

// --- Game Logic Constants ---
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K'];
const VALUES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
const SUITS: CardType['suit'][] = ['H', 'D', 'C', 'S'];

function createDeck(): CardType[] {
  const deck: CardType[] = [];
  SUITS.forEach(suit => {
    RANKS.forEach((rank, i) => {
      deck.push({ suit, rank, value: VALUES[i], faceUp: false });
    });
  });
  return deck.sort(() => Math.random() - 0.5); // Shuffle
}

// Layout for Tri-Peaks (28 cards)
// Row 1: 3 peaks (3 cards)
// Row 2: 6 cards (2 per peak)
// Row 3: 9 cards (3 per peak)
// Row 4: 10 cards (base)
// Total: 1+2+3+4 + 1+2+3+4 is NOT correct...
// Standard Tri-Peaks:
// Bottom row: 10 cards face up.
// Middle row: 9 cards (3 under each peak).
// Top row: 3 peaks of 3 cards.
// Total 28 cards.

// Simplified layout grid mapping for visual placement
// We use a flat array of 28 tableau cards.
// Indices 0-9: Bottom row (Face Up initially)
// Indices 10-18: Middle row (Face Down)
// Indices 19-24: Upper row (Face Down)
// Indices 25-27: Peaks (Face Down)
// Dependencies: A card is blocked if it is covered by cards in the row below it.
// Actually standard rules: Bottom row is face UP. Others face DOWN.
// When both cards covering a card are removed, it flips up.

export default function Game() {
  const [, params] = useRoute("/game/:roomId");
  const roomId = params?.roomId || null;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Local user identity (simple random ID for this session)
  const [playerName] = useState(() => `Player ${Math.floor(Math.random() * 1000)}`);
  
  const { status, gameState, startGame, updateScore } = useGameSocket(roomId, playerName);
  
  // Game State Local
  const [tableau, setTableau] = useState<CardType[]>([]);
  const [stock, setStock] = useState<CardType[]>([]);
  const [waste, setWaste] = useState<CardType[]>([]);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  
  // Initialize game board
  const initBoard = () => {
    const deck = createDeck();
    const initialTableau = deck.slice(0, 28).map((card, i) => ({
      ...card,
      // Bottom row (0-9) is face up initially in standard Tri-Peaks
      // We will actually invert the array logic for easier rendering top-down?
      // Let's stick to standard: 
      // Row 4 (Bottom): 10 cards (Indices 18-27) -> Face UP
      // Row 3: 9 cards (Indices 9-17) -> Face DOWN
      // Row 2: 6 cards (Indices 3-8) -> Face DOWN
      // Row 1 (Peaks): 3 cards (Indices 0-2) -> Face DOWN
      faceUp: i >= 18 
    }));
    
    setTableau(initialTableau);
    
    const remaining = deck.slice(28);
    const firstWaste = remaining.pop()!;
    firstWaste.faceUp = true;
    
    setWaste([firstWaste]);
    setStock(remaining);
    setScore(0);
    setStreak(0);
  };

  // Start game when server says so
  useEffect(() => {
    if (gameState?.status === 'playing' && tableau.length === 0) {
      initBoard();
    }
  }, [gameState?.status]);

  // Check which cards are playable (Face Up)
  // Logic: A card is blocked if it is covered by two cards from the row below.
  // We need a dependency map.
  // 0 covers nothing (top)
  // ... this is complex to map 1:1 without a strict grid.
  // Let's use a simpler approximation for MVP:
  // We just render them in rows. If a card has no cards "below" it in the specific structure, it's free.
  // For the sake of this demo, we'll make a simplified rule:
  // All cards are Face Up to start for maximum fun/speed, or implement simple row logic.
  // LET'S DO: All cards face up. It's a "Open Tri-Peaks" variant which is more beginner friendly and faster.
  
  // Handlers
  const handleCardClick = (card: CardType, index: number, source: 'tableau' | 'stock') => {
    if (gameState?.status !== 'playing') return;

    if (source === 'stock') {
      if (stock.length === 0) return;
      const newStock = [...stock];
      const nextCard = newStock.pop()!;
      nextCard.faceUp = true;
      setWaste(prev => [...prev, nextCard]);
      setStock(newStock);
      setStreak(0); // Reset streak on stock draw
      return;
    }

    // Tableau click
    const topWaste = waste[waste.length - 1];
    if (!topWaste) return;

    const diff = Math.abs(card.value - topWaste.value);
    const isMatch = diff === 1 || diff === 12; // 12 accounts for King(13) <-> Ace(1) wrap

    if (isMatch) {
      // Valid move
      const newTableau = [...tableau];
      newTableau[index] = { ...card, suit: 'S', rank: '', value: -1 }; // Mark as removed (placeholder)
      
      setTableau(newTableau);
      setWaste(prev => [...prev, card]);
      
      // Score calculation
      const newStreak = streak + 1;
      const points = 100 + (newStreak * 50); // Bonus for streaks
      const newScore = score + points;
      
      setStreak(newStreak);
      setScore(newScore);

      // Calculate progress (cards removed / 28)
      const removedCount = newTableau.filter(c => c.value === -1).length;
      const progress = Math.round((removedCount / 28) * 100);
      
      // Sync with server
      updateScore(newScore, progress);

      // Check win
      if (removedCount === 28) {
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    } else {
       toast({
         title: "Invalid Move",
         description: "Card must be one rank higher or lower.",
         variant: "destructive",
         duration: 1000
       });
    }
  };

  const copyRoomLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: "Copied!", description: "Room link copied to clipboard." });
  };

  if (!gameState) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white font-display text-2xl animate-pulse">
        Connecting to Game Server...
      </div>
    );
  }

  // LOBBY STATE
  if (gameState.status === 'waiting') {
    return (
      <div className="min-h-screen bg-[hsl(var(--background))] flex flex-col items-center justify-center p-4">
        <Card className="max-w-md w-full bg-white/95 backdrop-blur shadow-2xl p-8 text-center space-y-8">
          <div>
            <h1 className="text-4xl font-display text-slate-900 mb-2">Game Lobby</h1>
            <div className="inline-flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-md text-sm font-mono text-slate-500 cursor-pointer hover:bg-slate-200 transition-colors" onClick={copyRoomLink}>
              Room: {roomId} <Share2 className="w-3 h-3" />
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Players Joined</h3>
            {gameState.players.map(p => (
              <div key={p.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-green-400 to-blue-500 flex items-center justify-center text-white font-bold text-xs">
                    {p.name.charAt(0)}
                  </div>
                  <span className="font-medium text-slate-700">{p.name} {p.name === playerName && "(You)"}</span>
                </div>
                {p.isConnected ? (
                  <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                ) : (
                  <span className="w-2 h-2 rounded-full bg-red-300" />
                )}
              </div>
            ))}
            {gameState.players.length < 2 && (
              <div className="text-xs text-slate-400 italic py-2">Waiting for more players...</div>
            )}
          </div>

          <Button 
            size="lg" 
            className="w-full h-14 text-lg font-bold rounded-xl shadow-lg shadow-primary/20"
            onClick={startGame}
          >
            Start Game <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </Card>
      </div>
    );
  }

  // PLAYING STATE
  return (
    <div className="min-h-screen bg-[hsl(var(--background))] overflow-hidden relative touch-none">
      <GameHeader 
        players={gameState.players} 
        currentPlayerId={gameState.players.find(p => p.name === playerName)?.id || ''}
        roomId={roomId!}
        onLeave={() => setLocation('/')}
      />

      {/* Main Game Area */}
      <div className="h-full w-full flex flex-col items-center justify-center pt-20 pb-8 px-4 max-w-5xl mx-auto">
        
        {/* Tableau Container */}
        <div className="relative w-full aspect-[16/9] max-h-[60vh] mb-8">
           {/* 
             We manually position cards to form peaks.
             Using absolute positioning percentages for responsiveness.
           */}
           {tableau.map((card, i) => {
             if (card.value === -1) return null; // Removed card
             
             // Simple hardcoded positions for 3 peaks (first 3 rows) + bottom row
             // This is a simplified visual layout for MVP
             // Real implementation would calculate this dynamically based on tree structure
             
             // Row 0 (Peaks): 3 cards
             // Row 1: 6 cards
             // Row 2: 9 cards
             // Row 3 (Bottom): 10 cards - Indices 18-27
             
             let row = 0;
             let col = 0;
             let totalInRow = 0;
             
             // Very rough mapping logic for display
             if (i < 3) { row = 0; col = i; totalInRow = 3; }
             else if (i < 9) { row = 1; col = i - 3; totalInRow = 6; }
             else if (i < 18) { row = 2; col = i - 9; totalInRow = 9; }
             else { row = 3; col = i - 18; totalInRow = 10; }
             
             // Offsets for pyramid look
             // Row 0: Peak centers roughly at 15%, 50%, 85%
             // Let's do a simple grid and offset rows
             const rowY = row * 18; // % from top
             
             // Calculate X based on row width to center it
             // Spacing: 100% / 10 = 10% per card slot roughly
             const cardWidth = 9; // %
             const spacing = 1.5; // %
             const totalRowWidth = (totalInRow * cardWidth) + ((totalInRow - 1) * spacing);
             const startX = (100 - totalRowWidth) / 2;
             const x = startX + (col * (cardWidth + spacing));

             return (
               <div 
                 key={i} 
                 className="absolute w-[9%] aspect-[2/3]"
                 style={{ top: `${rowY}%`, left: `${x}%` }}
               >
                 <PlayingCard 
                   card={card}
                   index={i}
                   onClick={() => handleCardClick(card, i, 'tableau')}
                   className="w-full h-full"
                   isPlayable={true} // Simplified for MVP
                 />
               </div>
             );
           })}
        </div>

        {/* Controls Area (Stock + Waste) */}
        <div className="flex items-center gap-8 z-10">
          {/* Stock Pile */}
          <div className="relative w-20 h-28 sm:w-24 sm:h-36" onClick={() => handleCardClick(stock[0], 0, 'stock')}>
            {stock.length > 0 ? (
               // Render stack visual
               <>
                {stock.length > 2 && <div className="absolute top-1 left-1 w-full h-full bg-blue-700 rounded-lg border-2 border-white" />}
                {stock.length > 1 && <div className="absolute top-0.5 left-0.5 w-full h-full bg-blue-600 rounded-lg border-2 border-white" />}
                <div className="relative w-full h-full bg-blue-500 rounded-lg border-2 border-white flex items-center justify-center cursor-pointer hover:-translate-y-1 transition-transform card-shadow">
                  <span className="text-white font-display text-xl">{stock.length}</span>
                </div>
               </>
            ) : (
              <div className="w-full h-full rounded-lg border-2 border-white/20 flex items-center justify-center">
                <span className="text-white/20 text-xs">EMPTY</span>
              </div>
            )}
          </div>

          {/* Waste Pile */}
          <div className="relative w-20 h-28 sm:w-24 sm:h-36">
            <AnimatePresence>
              {waste.slice(-3).map((card, i) => (
                <div key={`${card.suit}-${card.rank}-${i}`} className="absolute inset-0">
                   <PlayingCard card={card} className="w-full h-full" />
                </div>
              ))}
            </AnimatePresence>
          </div>
          
          <div className="text-white font-display ml-4">
             <div className="text-xs opacity-70 uppercase tracking-widest">Score</div>
             <div className="text-4xl">{score}</div>
          </div>
        </div>

      </div>

      {/* Game Over Screen */}
      {gameState.status === 'ended' && (
        <GameOverModal 
          players={gameState.players} 
          currentPlayerId={gameState.players.find(p => p.name === playerName)?.id || ''}
          onPlayAgain={() => window.location.reload()}
        />
      )}
    </div>
  );
}
