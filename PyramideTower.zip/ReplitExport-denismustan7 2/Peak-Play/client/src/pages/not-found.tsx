import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[hsl(var(--background))] p-4">
      <div className="text-center space-y-6 max-w-md mx-auto p-8 bg-white/10 backdrop-blur-md rounded-3xl border border-white/20">
        <div className="flex justify-center">
          <AlertCircle className="h-20 w-20 text-red-400" />
        </div>
        <h1 className="text-5xl font-display text-white">404</h1>
        <p className="text-lg text-white/80">
          The card you're looking for must be lost in the shuffle.
        </p>
        <Link href="/">
          <Button size="lg" className="w-full font-bold text-lg h-12 rounded-xl">
            Return to Lobby
          </Button>
        </Link>
      </div>
    </div>
  );
}
