import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { User, Trophy, LogOut } from "lucide-react";
import type { Player } from "@shared/schema";

interface PlayerBadgeProps {
  player: Player;
  isCurrent: boolean;
}

function PlayerBadge({ player, isCurrent }: PlayerBadgeProps) {
  return (
    <div className={cn(
      "flex items-center gap-3 px-4 py-2 rounded-full backdrop-blur-md transition-all duration-300",
      isCurrent 
        ? "bg-primary text-primary-foreground shadow-lg scale-105 border-2 border-yellow-300" 
        : "bg-black/30 text-white border border-white/10"
    )}>
      <div className="relative">
        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white/20 flex items-center justify-center">
          <User className="w-5 h-5 sm:w-6 sm:h-6" />
        </div>
        {!player.isConnected && (
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-black" />
        )}
      </div>
      
      <div className="flex flex-col min-w-[80px]">
        <div className="flex justify-between items-center text-xs sm:text-sm font-bold">
          <span className="truncate max-w-[100px]">{player.name}</span>
          <span>{player.score}</span>
        </div>
        <div className="w-full h-1.5 bg-black/20 rounded-full mt-1 overflow-hidden">
          <div 
            className="h-full bg-yellow-400 transition-all duration-500 ease-out"
            style={{ width: `${player.progress}%` }}
          />
        </div>
      </div>
    </div>
  );
}

interface GameHeaderProps {
  players: Player[];
  currentPlayerId: string;
  roomId: string;
  onLeave: () => void;
}

export function GameHeader({ players, currentPlayerId, roomId, onLeave }: GameHeaderProps) {
  // Sort players: current player first, then by score
  const sortedPlayers = [...players].sort((a, b) => {
    if (a.id === currentPlayerId) return -1;
    if (b.id === currentPlayerId) return 1;
    return b.score - a.score;
  });

  return (
    <div className="fixed top-0 left-0 right-0 p-4 pointer-events-none z-50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        {/* Room Info */}
        <div className="bg-black/40 backdrop-blur-md px-4 py-1.5 rounded-lg text-white/80 text-xs font-mono pointer-events-auto flex items-center gap-2">
          <span>ROOM: {roomId}</span>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 text-white/50 hover:text-white hover:bg-white/10"
            onClick={onLeave}
          >
            <LogOut className="w-3 h-3" />
          </Button>
        </div>

        {/* Players List */}
        <div className="flex flex-wrap gap-2 sm:gap-4 pointer-events-auto">
          {sortedPlayers.map(player => (
            <PlayerBadge 
              key={player.id} 
              player={player} 
              isCurrent={player.id === currentPlayerId} 
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export function GameOverModal({ 
  players, 
  currentPlayerId,
  onPlayAgain 
}: { 
  players: Player[], 
  currentPlayerId: string,
  onPlayAgain: () => void 
}) {
  const winner = [...players].sort((a, b) => b.score - a.score)[0];
  const isWinner = winner.id === currentPlayerId;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-white rounded-3xl p-8 max-w-md w-full text-center shadow-2xl animate-in zoom-in duration-300">
        <div className="flex justify-center mb-6">
          <div className={cn(
            "w-24 h-24 rounded-full flex items-center justify-center text-4xl shadow-xl",
            isWinner ? "bg-yellow-400 text-yellow-900" : "bg-slate-200 text-slate-500"
          )}>
            <Trophy className="w-12 h-12" />
          </div>
        </div>
        
        <h2 className="text-4xl font-display text-slate-900 mb-2">
          {isWinner ? "You Won!" : "Game Over"}
        </h2>
        
        <p className="text-slate-500 mb-8 font-medium">
          {isWinner 
            ? `Amazing job! You cleared the peaks with ${winner.score} points.` 
            : `${winner.name} won with ${winner.score} points. Better luck next time!`}
        </p>

        <div className="space-y-3">
          {players
            .sort((a, b) => b.score - a.score)
            .map((player, i) => (
            <div key={player.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
              <div className="flex items-center gap-3">
                <span className="font-display text-slate-400 w-4">{i + 1}</span>
                <span className={cn("font-bold", player.id === currentPlayerId && "text-primary-foreground")}>
                  {player.name} {player.id === currentPlayerId && "(You)"}
                </span>
              </div>
              <span className="font-mono font-bold text-slate-600">{player.score}</span>
            </div>
          ))}
        </div>

        <Button 
          onClick={onPlayAgain}
          className="w-full mt-8 h-12 text-lg font-bold rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20"
        >
          Back to Lobby
        </Button>
      </div>
    </div>
  );
}
