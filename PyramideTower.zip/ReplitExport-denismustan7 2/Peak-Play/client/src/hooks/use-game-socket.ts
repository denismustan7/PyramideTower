import { useEffect, useRef, useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import type { WSMessage, GameState } from '@shared/schema';

type ConnectionStatus = 'connecting' | 'connected' | 'disconnected';

export function useGameSocket(roomId: string | null, playerName: string) {
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [gameState, setGameState] = useState<GameState | null>(null);
  const socketRef = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  // Connect to WS
  useEffect(() => {
    if (!roomId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    setStatus('connecting');
    const ws = new WebSocket(wsUrl);
    socketRef.current = ws;

    ws.onopen = () => {
      setStatus('connected');
      // Join room immediately upon connection
      ws.send(JSON.stringify({
        type: 'JOIN_ROOM',
        payload: { roomId, playerName }
      }));
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WSMessage;
        
        switch (message.type) {
          case 'GAME_STATE':
            setGameState(message.payload);
            break;
          case 'ERROR':
            toast({
              title: "Error",
              description: message.payload.message,
              variant: "destructive"
            });
            break;
        }
      } catch (e) {
        console.error('Failed to parse WS message', e);
      }
    };

    ws.onclose = () => {
      setStatus('disconnected');
    };

    return () => {
      ws.close();
    };
  }, [roomId, playerName, toast]);

  // Actions
  const startGame = useCallback(() => {
    if (socketRef.current?.readyState === WebSocket.OPEN && roomId) {
      socketRef.current.send(JSON.stringify({
        type: 'START_GAME',
        payload: { roomId }
      }));
    }
  }, [roomId]);

  const updateScore = useCallback((score: number, progress: number) => {
    if (socketRef.current?.readyState === WebSocket.OPEN && roomId) {
      socketRef.current.send(JSON.stringify({
        type: 'UPDATE_SCORE',
        payload: { roomId, score, progress }
      }));
    }
  }, [roomId]);

  return {
    status,
    gameState,
    startGame,
    updateScore
  };
}
