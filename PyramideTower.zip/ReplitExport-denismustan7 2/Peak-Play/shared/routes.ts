import { z } from 'zod';

export const api = {
  lobbies: {
    create: {
      method: 'POST' as const,
      path: '/api/lobbies',
      input: z.object({}),
      responses: {
        201: z.object({ roomId: z.string() }),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/lobbies',
      responses: {
        200: z.array(z.object({
          roomId: z.string(),
          playerCount: z.number(),
          status: z.string()
        })),
      },
    },
  },
};
