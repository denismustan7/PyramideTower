import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  roomCode: text("room_code").notNull(),
  status: text("status").notNull().default("waiting"), // waiting, playing, ended
  createdAt: timestamp("created_at").defaultNow(),
});

export const results = pgTable("results", {
  id: serial("id").primaryKey(),
  gameId: integer("game_id").notNull(),
  playerName: text("player_name").notNull(),
  score: integer("score").notNull(),
  isWinner: boolean("is_winner").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// === SCHEMAS ===
export const insertGameSchema = createInsertSchema(games).omit({ id: true, createdAt: true });
export const insertResultSchema = createInsertSchema(results).omit({ id: true, createdAt: true });

// === TYPES ===
export type Game = typeof games.$inferSelect;
export type Result = typeof results.$inferSelect;

// === SHARED GAME TYPES ===
export type Card = {
  suit: 'H' | 'D' | 'C' | 'S';
  rank: string;
  value: number;
  faceUp: boolean;
};

export type Player = {
  id: string;
  name: string;
  score: number;
  progress: number;
  isConnected: boolean;
};

export type GameState = {
  roomId: string;
  status: 'waiting' | 'playing' | 'ended';
  players: Player[];
  startTime?: number;
};

// WebSocket Message Types (for socket.io events)
export const WS_EVENTS = {
  JOIN_ROOM: 'join_room',
  START_GAME: 'start_game',
  UPDATE_SCORE: 'update_score',
  GAME_STATE: 'game_state',
  ERROR: 'error'
} as const;
