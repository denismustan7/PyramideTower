import arcade
import random
import os

# Force software rendering for headless/VNC environments
os.environ["LIBGL_ALWAYS_SOFTWARE"] = "1"

# --- Einstellungen ---
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
SCREEN_TITLE = "Magic Towers 2025 - Professional Clone"

# Karten-Größe
CARD_SCALE = 0.6
CARD_WIDTH = 140 * CARD_SCALE
CARD_HEIGHT = 190 * CARD_SCALE

# Abstände im Layout
X_SPACING = 50
Y_SPACING = 40

class Card(arcade.SpriteSolidColor):
    """ Repräsentiert eine einzelne Spielkarte """
    def __init__(self, value, suit, x, y):
        super().__init__(int(CARD_WIDTH), int(CARD_HEIGHT), arcade.color.WHITE)
        self.value = value  # 1 (Ass) bis 13 (König)
        self.suit = suit
        self.center_x = x
        self.center_y = y
        self.is_face_up = False
        self.blocking_cards = [] # Karten, die auf dieser Karte liegen

    def draw_content(self):
        """ Zeichnet den Wert auf die Karte, falls sie offen ist """
        if self.is_face_up:
            color = arcade.color.RED if self.suit in ["Hearts", "Diamonds"] else arcade.color.BLACK
            val_str = {1: "A", 11: "J", 12: "Q", 13: "K"}.get(self.value, str(self.value))
            arcade.draw_text(val_str, self.center_x, self.center_y, color, 18, anchor_x="center", anchor_y="center", bold=True)
        else:
            arcade.draw_rectangle_filled(self.center_x, self.center_y, CARD_WIDTH-10, CARD_HEIGHT-10, arcade.color.BLUE_GRAY)

class MagicTowers(arcade.Window):
    def __init__(self):
        # We explicitly request OpenGL 3.3 for arcade 3.x
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE, resizable=False, antialiasing=True)
        arcade.set_background_color(arcade.color.DARK_GREEN)
        
        self.cards_in_towers = arcade.SpriteList()
        self.draw_pile = []
        self.discard_pile_top = None
        self.score = 0
        self.streak = 0 # Für Bonus-Multiplikator

    def setup(self):
        # 1. Deck erstellen
        deck = []
        for suit in ["Hearts", "Diamonds", "Spades", "Clubs"]:
            for val in range(1, 14):
                deck.append((val, suit))
        random.shuffle(deck)

        # 2. Türme aufbauen (Layout Logik)
        self.cards_in_towers = arcade.SpriteList()
        tower_starts = [200, 500, 800]
        
        # Wir speichern die Karten in Ebenen, um die Blockierung zu berechnen
        all_tower_cards = []

        for start_x in tower_starts:
            tower_layers = []
            # Ebene 0 (Spitze): 1 Karte
            c0 = Card(*deck.pop(), start_x, 550)
            tower_layers.append([c0])
            # Ebene 1: 2 Karten
            c1_1 = Card(*deck.pop(), start_x - X_SPACING//2, 550 - Y_SPACING)
            c1_2 = Card(*deck.pop(), start_x + X_SPACING//2, 550 - Y_SPACING)
            tower_layers.append([c1_1, c1_2])
            # Ebene 2: 3 Karten
            c2_1 = Card(*deck.pop(), start_x - X_SPACING, 550 - 2*Y_SPACING)
            c2_2 = Card(*deck.pop(), start_x, 550 - 2*Y_SPACING)
            c2_3 = Card(*deck.pop(), start_x + X_SPACING, 550 - 2*Y_SPACING)
            tower_layers.append([c2_1, c2_2, c2_3])
            
            # Blockier-Abhängigkeiten setzen (Ebene darüber wird von Ebene darunter blockiert)
            c0.blocking_cards = [c1_1, c1_2]
            c1_1.blocking_cards = [c2_1, c2_2]
            c1_2.blocking_cards = [c2_2, c2_3]
            
            for layer in tower_layers:
                for card in layer:
                    self.cards_in_towers.append(card)

        # Ebene 3 (Basis): 10 Karten durchgehend
        base_y = 550 - 3*Y_SPACING
        last_row = []
        for i in range(10):
            c = Card(*deck.pop(), 115 + i * 85, base_y)
            c.is_face_up = True # Unterste Reihe ist immer offen
            last_row.append(c)
            self.cards_in_towers.append(c)

        # 3. Restliche Karten in den Nachziehstapel
        self.draw_pile = deck
        # Erste Karte auf den Ablagestapel
        val, suit = self.draw_pile.pop()
        self.discard_pile_top = Card(val, suit, SCREEN_WIDTH // 2, 150)
        self.discard_pile_top.is_face_up = True

    def update_visibility(self):
        """ Prüft, ob Karten freigeschaltet wurden """
        for card in self.cards_in_towers:
            if not card.is_face_up:
                # Wenn alle Karten, die diese blockieren, weg sind (nicht mehr in SpriteList)
                still_blocking = [c for c in card.blocking_cards if c in self.cards_in_towers]
                if not still_blocking:
                    card.is_face_up = True

    def on_draw(self):
        self.clear()
        for card in self.cards_in_towers:
            card.draw()
            card.draw_content()
        
        self.discard_pile_top.draw()
        self.discard_pile_top.draw_content()

        # UI
        arcade.draw_text(f"Score: {self.score}", 20, 20, arcade.color.WHITE, 20)
        arcade.draw_text(f"Stapel: {len(self.draw_pile)}", 850, 20, arcade.color.LIGHT_GRAY, 16)
        arcade.draw_text("Nachziehen", 850, 50, arcade.color.GOLD, 14)

    def on_mouse_press(self, x, y, button, modifiers):
        # 1. Klick auf Turm-Karten
        cards = arcade.get_sprites_at_point((x, y), self.cards_in_towers)
        if cards:
            clicked = cards[-1]
            if clicked.is_face_up:
                # Logik: +/- 1 Wert
                diff = abs(clicked.value - self.discard_pile_top.value)
                if diff == 1 or diff == 12: # 12 ist K <-> A
                    # Gültiger Zug
                    self.discard_pile_top.value = clicked.value
                    self.discard_pile_top.suit = clicked.suit
                    clicked.remove_from_sprite_lists()
                    self.streak += 1
                    self.score += 10 * self.streak
                    self.update_visibility()
            return

        # 2. Klick auf Nachziehstapel (Rechts unten)
        if x > 800 and y < 100:
            if self.draw_pile:
                val, suit = self.draw_pile.pop()
                self.discard_pile_top.value = val
                self.discard_pile_top.suit = suit
                self.streak = 0 # Streak bricht ab
                self.score = max(0, self.score - 5)

def main():
    game = MagicTowers()
    game.setup()
    arcade.run()

if __name__ == "__main__":
    main()
