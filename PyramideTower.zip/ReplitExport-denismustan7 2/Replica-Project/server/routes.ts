import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.snippets.list.path, async (req, res) => {
    const snippets = await storage.getSnippets();
    res.json(snippets);
  });

  app.get(api.snippets.get.path, async (req, res) => {
    const snippet = await storage.getSnippet(Number(req.params.id));
    if (!snippet) {
      return res.status(404).json({ message: 'Snippet not found' });
    }
    res.json(snippet);
  });

  app.post(api.snippets.create.path, async (req, res) => {
    try {
      const input = api.snippets.create.input.parse(req.body);
      const snippet = await storage.createSnippet(input);
      res.status(201).json(snippet);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.put(api.snippets.update.path, async (req, res) => {
    try {
      const input = api.snippets.update.input.parse(req.body);
      const snippet = await storage.updateSnippet(Number(req.params.id), input);
      if (!snippet) {
        return res.status(404).json({ message: 'Snippet not found' });
      }
      res.json(snippet);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.snippets.delete.path, async (req, res) => {
    await storage.deleteSnippet(Number(req.params.id));
    res.status(204).send();
  });

  // Seed data if empty
  const existing = await storage.getSnippets();
  if (existing.length === 0) {
    await storage.createSnippet({
      title: "Hello World",
      code: "console.log('Hello from Repl!');\nconst x = 10;\nconst y = 20;\nconsole.log(`Sum is: ${x + y}`);",
      language: "javascript"
    });
    await storage.createSnippet({
      title: "Loop Example",
      code: "for (let i = 1; i <= 5; i++) {\n  console.log(`Count: ${i}`);\n}",
      language: "javascript"
    });
  }

  return httpServer;
}
