import React, { useState, useEffect } from "react";
import Editor from "react-simple-code-editor";
import { highlight, languages } from "prismjs";
import "prismjs/components/prism-clike";
import "prismjs/components/prism-javascript";
import "prismjs/themes/prism-tomorrow.css"; // Dark theme
import { Play, Save, Loader2, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CodeEditorProps {
  initialCode: string;
  initialTitle: string;
  isSaving: boolean;
  onSave: (title: string, code: string) => void;
  onRun: (code: string) => void;
}

export function CodeEditor({ initialCode, initialTitle, isSaving, onSave, onRun }: CodeEditorProps) {
  const [code, setCode] = useState(initialCode);
  const [title, setTitle] = useState(initialTitle);

  // Sync internal state when prop changes (e.g. switching snippets)
  useEffect(() => {
    setCode(initialCode);
    setTitle(initialTitle);
  }, [initialCode, initialTitle]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      onSave(title, code);
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      onRun(code);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#282c34] text-white" onKeyDown={handleKeyDown}>
      {/* Editor Toolbar */}
      <div className="flex items-center justify-between px-6 py-3 bg-background border-b border-border shadow-sm z-10">
        <div className="flex-1 max-w-lg">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Untitled Snippet"
            className="w-full bg-transparent text-lg font-bold text-foreground focus:outline-none placeholder:text-muted-foreground/50"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <Button
            onClick={() => onRun(code)}
            variant="secondary"
            className="gap-2 bg-secondary hover:bg-secondary/80 text-secondary-foreground border border-white/5"
          >
            <Play className="w-4 h-4 fill-current" />
            <span className="hidden sm:inline">Run</span>
            <span className="text-xs text-muted-foreground ml-1 hidden lg:inline">⌘↵</span>
          </Button>
          
          <Button
            onClick={() => onSave(title, code)}
            disabled={isSaving}
            className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all"
          >
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            <span className="hidden sm:inline">{isSaving ? 'Saving...' : 'Save'}</span>
            <span className="text-xs opacity-70 ml-1 hidden lg:inline">⌘S</span>
          </Button>
        </div>
      </div>

      {/* Code Editor Area */}
      <div className="flex-1 overflow-y-auto relative font-mono text-sm prism-editor">
        <Editor
          value={code}
          onValueChange={setCode}
          highlight={code => highlight(code, languages.js, 'javascript')}
          padding={24}
          className="font-mono min-h-full"
          style={{
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: 14,
            backgroundColor: '#282c34',
            color: '#abb2bf',
          }}
          textareaClassName="focus:outline-none"
        />
      </div>
      
      {/* Status Bar */}
      <div className="px-4 py-1.5 bg-primary/10 text-primary text-xs font-mono flex items-center justify-between border-t border-primary/10 select-none">
        <div className="flex gap-4">
          <span>JavaScript</span>
          <span>{code.length} chars</span>
        </div>
        <span>Ln {code.split('\n').length}</span>
      </div>
    </div>
  );
}
