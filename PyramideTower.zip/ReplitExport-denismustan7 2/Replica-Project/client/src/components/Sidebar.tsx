import { Code2, Plus, Search, Trash2, FileCode } from "lucide-react";
import { useState } from "react";
import type { Snippet } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface SidebarProps {
  snippets: Snippet[];
  activeId: number | null;
  onSelect: (id: number) => void;
  onNew: () => void;
  onDelete: (id: number, e: React.MouseEvent) => void;
}

export function Sidebar({ snippets, activeId, onSelect, onNew, onDelete }: SidebarProps) {
  const [search, setSearch] = useState("");

  const filteredSnippets = snippets.filter(s => 
    s.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="w-64 md:w-72 bg-card border-r border-border flex flex-col h-full shrink-0">
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-2 mb-6 text-primary">
          <Code2 className="w-6 h-6" />
          <h1 className="font-bold text-lg tracking-tight text-foreground">Snippets</h1>
        </div>

        <button
          onClick={onNew}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium text-sm hover:bg-primary/90 hover:shadow-lg hover:shadow-primary/20 transition-all active:translate-y-0.5"
        >
          <Plus className="w-4 h-4" />
          New Snippet
        </button>

        <div className="mt-4 relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
          <input
            type="text"
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-background border border-input rounded-md pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all placeholder:text-muted-foreground/70"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filteredSnippets.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-muted-foreground text-center px-4">
            <FileCode className="w-8 h-8 mb-2 opacity-20" />
            <p className="text-xs">No snippets found</p>
          </div>
        ) : (
          filteredSnippets.map((snippet) => (
            <div
              key={snippet.id}
              onClick={() => onSelect(snippet.id)}
              className={`
                group relative flex flex-col gap-1 p-3 rounded-md cursor-pointer transition-all duration-200 border border-transparent
                ${activeId === snippet.id 
                  ? "bg-secondary/50 border-primary/20 text-foreground shadow-sm" 
                  : "text-muted-foreground hover:bg-secondary/30 hover:text-foreground"
                }
              `}
            >
              <div className="flex items-start justify-between">
                <span className="font-medium text-sm truncate pr-6">{snippet.title}</span>
                <button
                  onClick={(e) => onDelete(snippet.id, e)}
                  className="absolute right-2 top-3 opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/10 hover:text-destructive rounded transition-all"
                  title="Delete snippet"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex items-center gap-2 text-[10px] opacity-70">
                <span className="uppercase tracking-wider font-semibold text-primary/80">{snippet.language}</span>
                <span>•</span>
                <span>{snippet.createdAt ? formatDistanceToNow(new Date(snippet.createdAt), { addSuffix: true }) : 'Just now'}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
