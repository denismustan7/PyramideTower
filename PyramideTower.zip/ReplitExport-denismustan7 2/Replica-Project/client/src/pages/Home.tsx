import { useState, useCallback } from "react";
import { Sidebar } from "@/components/Sidebar";
import { CodeEditor } from "@/components/Editor";
import { Console, LogMessage } from "@/components/Console";
import { useSnippets, useCreateSnippet, useUpdateSnippet, useDeleteSnippet } from "@/hooks/use-snippets";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_CODE = `// Welcome to your JS Snippet Manager!
// Write some code here and press Run (⌘+Enter).

function greet(name) {
  console.log("Hello, " + name + "!");
  return true;
}

const result = greet("Developer");
console.log("Result: " + result);
console.warn("This is a warning example");
console.error("This is an error example");
`;

export default function Home() {
  const { data: snippets, isLoading } = useSnippets();
  const createSnippet = useCreateSnippet();
  const updateSnippet = useUpdateSnippet();
  const deleteSnippet = useDeleteSnippet();
  const { toast } = useToast();

  const [activeSnippetId, setActiveSnippetId] = useState<number | null>(null);
  const [logs, setLogs] = useState<LogMessage[]>([]);
  
  // Local state for "New Snippet" mode when activeSnippetId is null
  const [tempTitle, setTempTitle] = useState("Untitled Snippet");
  const [tempCode, setTempCode] = useState(DEFAULT_CODE);

  // Derive current view state
  const activeSnippet = snippets?.find(s => s.id === activeSnippetId);
  const currentCode = activeSnippet ? activeSnippet.code : tempCode;
  const currentTitle = activeSnippet ? activeSnippet.title : tempTitle;

  const handleSelectSnippet = (id: number) => {
    setActiveSnippetId(id);
    setLogs([]); // Clear console on switch
  };

  const handleNewSnippet = () => {
    setActiveSnippetId(null);
    setTempTitle("Untitled Snippet");
    setTempCode(DEFAULT_CODE);
    setLogs([]);
  };

  const handleSave = async (title: string, code: string) => {
    if (activeSnippetId) {
      await updateSnippet.mutateAsync({ 
        id: activeSnippetId, 
        title, 
        code 
      });
    } else {
      const newSnippet = await createSnippet.mutateAsync({
        title,
        code,
        language: "javascript"
      });
      setActiveSnippetId(newSnippet.id);
    }
  };

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this snippet?")) {
      await deleteSnippet.mutateAsync(id);
      if (activeSnippetId === id) {
        handleNewSnippet();
      }
    }
  };

  const handleRun = useCallback((code: string) => {
    setLogs([]); // Clear previous logs
    
    // Capture console output
    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;
    const originalInfo = console.info;

    const addLog = (type: LogMessage['type'], args: any[]) => {
      const content = args.map(arg => 
        typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
      ).join(' ');
      
      setLogs(prev => [...prev, { type, content, timestamp: Date.now() }]);
    };

    console.log = (...args) => addLog('log', args);
    console.warn = (...args) => addLog('warn', args);
    console.error = (...args) => addLog('error', args);
    console.info = (...args) => addLog('info', args);

    try {
      // Execute code safely-ish
      // wrapping in async IIFE to support await if needed in future
      const runCode = new Function(code);
      runCode();
    } catch (err) {
      console.error(err);
    } finally {
      // Restore console
      console.log = originalLog;
      console.warn = originalWarn;
      console.error = originalError;
      console.info = originalInfo;
    }
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background text-primary">
        <Loader2 className="w-10 h-10 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar 
        snippets={snippets || []} 
        activeId={activeSnippetId}
        onSelect={handleSelectSnippet}
        onNew={handleNewSnippet}
        onDelete={handleDelete}
      />
      
      <div className="flex-1 flex flex-col h-full min-w-0">
        <PanelGroup direction="vertical">
          <Panel defaultSize={70} minSize={30}>
            <CodeEditor 
              key={activeSnippetId || 'new'} // Force re-render on switch
              initialCode={currentCode}
              initialTitle={currentTitle}
              isSaving={createSnippet.isPending || updateSnippet.isPending}
              onSave={handleSave}
              onRun={handleRun}
            />
          </Panel>
          
          <PanelResizeHandle className="h-2 bg-card border-t border-b border-border hover:bg-primary/20 transition-colors flex justify-center items-center group">
            <div className="w-8 h-1 bg-border rounded-full group-hover:bg-primary/50 transition-colors" />
          </PanelResizeHandle>
          
          <Panel defaultSize={30} minSize={10}>
            <Console 
              logs={logs} 
              onClear={() => setLogs([])} 
            />
          </Panel>
        </PanelGroup>
      </div>
    </div>
  );
}
