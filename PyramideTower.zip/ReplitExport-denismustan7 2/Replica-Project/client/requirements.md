## Packages
react-simple-code-editor | Lightweight code editor component
prismjs | Syntax highlighting for the code editor
framer-motion | For smooth transitions and animations
clsx | Utility for conditional classes (standard in shadcn)
tailwind-merge | Utility for merging tailwind classes (standard in shadcn)

## Notes
The editor executes code using `new Function()`.
Console capture overrides `console.log` temporarily within the execution context.
VS Code inspired dark theme is the default.
