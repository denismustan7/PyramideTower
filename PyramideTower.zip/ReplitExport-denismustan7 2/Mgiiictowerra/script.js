const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let game = {
    players: [0, 0, 0, 0],
    currentPlayer: 0,
    round: 1,
    time: 60,
    maxTime: 60,
    deck: [],
    towers: [],
    activeCard: null,
    streak: 0,
    timerInterval: null
};

const CARD_W = 75;
const CARD_H = 110;

function initGame() {
    // Zeitberechnung: 60s - (Runde-1)*5s
    game.maxTime = Math.max(15, 60 - (game.round - 1) * 5);
    game.time = game.maxTime;
    
    // Deck mischen
    game.deck = [];
    for(let s=0; s<4; s++) {
        const suits = ["♥","♦","♣","♠"];
        const colors = ["#d00", "#d00", "#000", "#000"];
        for(let v=1; v<=13; v++) {
            game.deck.push({v, s: suits[s], color: colors[s]});
        }
    }
    game.deck.sort(() => Math.random() - 0.5);

    game.towers = [];
    // Die 3 Türme (Original Layout)
    [180, 500, 820].forEach(x => createTower(x));

    // Die untere Reihe (10 Karten)
    for(let i=0; i<10; i++) {
        game.towers.push({ x: 105 + i*88, y: 420, v: game.deck.pop(), open: true, blocks: [] });
    }

    game.activeCard = game.deck.pop();
    updateUI();
    if(game.timerInterval) clearInterval(game.timerInterval);
    game.timerInterval = setInterval(tick, 100);
    draw();
}

function createTower(x) {
    // Ebene 1 (Spitze)
    let t = { x, y: 150, v: game.deck.pop(), open: false, blocks: [] };
    // Ebene 2
    let m1 = { x: x-40, y: 240, v: game.deck.pop(), open: false, blocks: [] };
    let m2 = { x: x+40, y: 240, v: game.deck.pop(), open: false, blocks: [] };
    // Ebene 3
    let b1 = { x: x-80, y: 330, v: game.deck.pop(), open: false, blocks: [] };
    let b2 = { x: x, y: 330, v: game.deck.pop(), open: false, blocks: [] };
    let b3 = { x: x+80, y: 330, v: game.deck.pop(), open: false, blocks: [] };

    // Blockier-Logik setzen (Indizes im game.towers Array)
    let startIdx = game.towers.length;
    t.blocks = [startIdx + 1, startIdx + 2];
    m1.blocks = [startIdx + 3, startIdx + 4];
    m2.blocks = [startIdx + 4, startIdx + 5];

    game.towers.push(t, m1, m2, b1, b2, b3);
}

function drawCard(c, x, y, open) {
    ctx.save();
    ctx.translate(x, y);
    
    // Schatten & Rahmen
    ctx.shadowBlur = 10; ctx.shadowColor = "rgba(0,0,0,0.5)";
    ctx.fillStyle = open ? "#fff" : "#1a2a6c"; // Blau für Rückseite
    ctx.beginPath();
    ctx.roundRect(-CARD_W/2, -CARD_H/2, CARD_W, CARD_H, 10);
    ctx.fill();
    ctx.strokeStyle = open ? "#FFD700" : "#444";
    ctx.lineWidth = 2;
    ctx.stroke();

    if(open && c && c.v) {
        ctx.shadowBlur = 0;
        ctx.fillStyle = c.v.color;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        
        // Large Value
        ctx.font = "bold 28px 'Georgia'";
        let val = c.v.v;
        if(val === 1) val = "A"; else if(val === 11) val = "J"; else if(val === 12) val = "Q"; else if(val === 13) val = "K";
        ctx.fillText(val, 0, -10);
        
        // Suit Symbol
        ctx.font = "24px Arial";
        ctx.fillText(c.v.s, 0, 25);
        
        // Mini symbols corners
        ctx.font = "bold 14px Arial";
        ctx.fillText(val, -CARD_W/2 + 15, -CARD_H/2 + 20);
        ctx.fillText(val, CARD_W/2 - 15, CARD_H/2 - 20);
    } else if (!open) {
        // Pattern for closed cards
        ctx.strokeStyle = "rgba(255,255,255,0.1)";
        ctx.lineWidth = 1;
        for(let i=-20; i<=20; i+=10) {
            ctx.beginPath();
            ctx.moveTo(i-10, -30);
            ctx.lineTo(i+10, 30);
            ctx.stroke();
        }
    }
    ctx.restore();
}

function tick() {
    game.time -= 0.1;
    if(game.time <= 0) switchPlayer();
    updateUI();
    draw();
}

function switchPlayer() {
    game.currentPlayer = (game.currentPlayer + 1) % 4;
    game.time = game.maxTime;
    game.streak = 0;
}

function draw() {
    ctx.clearRect(0,0,canvas.width, canvas.height);
    
    // Türme prüfen & zeichnen
    game.towers.forEach(c => {
        if(c) {
            const isBlocked = c.blocks.some(idx => game.towers[idx] !== null);
            if(!isBlocked) c.open = true;
            drawCard(c, c.x, c.y, c.open);
        }
    });

    // Aktive Zone
    ctx.fillStyle = "rgba(255,215,0,0.1)";
    ctx.beginPath(); ctx.arc(500, 540, 80, 0, Math.PI*2); ctx.fill();
    drawCard({v: game.activeCard}, 500, 540, true);
    
    // Stapel
    if(game.deck.length > 0) drawCard({}, 880, 540, false);
    
    ctx.fillStyle = "#FFD700";
    ctx.font = "bold 16px 'Georgia'";
    ctx.textAlign = "center";
    ctx.fillText("ACTIVE", 500, 620);
    ctx.fillText("DECK (" + game.deck.length + ")", 880, 620);
}

function updateUI() {
    document.getElementById("round-num").innerText = game.round;
    document.getElementById("time-left").innerText = Math.ceil(game.time) + "s";
    const timerBar = document.getElementById("timer-bar");
    const perc = (game.time / game.maxTime * 100);
    timerBar.style.width = Math.max(0, perc) + "%";
    timerBar.style.background = perc < 25 ? "#ff0000" : "#FFD700";
    
    for(let i=0; i<4; i++) {
        let el = document.getElementById(`p${i+1}`);
        if(el) {
            el.querySelector(".score").innerText = game.players[i];
            el.className = (game.currentPlayer === i) ? "player-info active" : "player-info";
        }
    }
}

canvas.addEventListener("mousedown", (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (canvas.width / rect.width);
    const my = (e.clientY - rect.top) * (canvas.height / rect.height);

    // Klick auf Karten im Turm
    for(let i=game.towers.length-1; i>=0; i--) {
        let c = game.towers[i];
        if(c && c.open && Math.abs(mx-c.x)<CARD_W/2 && Math.abs(my-c.y)<CARD_H/2) {
            let diff = Math.abs(c.v.v - game.activeCard.v);
            if(diff === 1 || diff === 12) {
                game.activeCard = c.v;
                game.towers[i] = null;
                game.players[game.currentPlayer] += 100 + (game.streak * 25);
                game.streak++;
                if(game.towers.every(t => t === null)) showOverlay("Runde Beendet!");
                draw();
                updateUI();
                return;
            }
        }
    }

    // Klick auf Stapel
    if(mx > 840 && mx < 920 && my > 480 && my < 600 && game.deck.length > 0) {
        game.activeCard = game.deck.pop();
        switchPlayer();
        draw();
        updateUI();
    }
});

function showOverlay(title) {
    clearInterval(game.timerInterval);
    const overlay = document.getElementById("overlay");
    const titleEl = document.getElementById("overlay-title");
    const descEl = document.getElementById("overlay-desc");
    
    titleEl.innerText = title;
    if(game.round >= 10) {
        let maxScore = Math.max(...game.players);
        let winner = game.players.indexOf(maxScore) + 1;
        titleEl.innerText = "FINALE BEENDET!";
        descEl.innerText = `SPIELER ${winner} IST DER CHAMPION MIT ${maxScore} PUNKTEN!`;
    } else {
        descEl.innerText = "Nächste Runde startet...";
    }
    overlay.style.display = "flex";
}

function nextRound() {
    if(game.round < 10) {
        game.round++;
        document.getElementById("overlay").style.display = "none";
        initGame();
    } else {
        location.reload();
    }
}

initGame();
window.nextRound = nextRound;
