const socket = io();
const $ = (id) => document.getElementById(id);

const lobbyEl = $("lobby");
const roomEl = $("room");
const gameEl = $("game");

const nameEl = $("name");
const codeEl = $("code");
const lobbyMsg = $("lobbyMsg");
const roomMsg = $("roomMsg");

const createBtn = $("createBtn");
const joinBtn = $("joinBtn");
const leaveBtn = $("leaveBtn");
const startBtn = $("startBtn");

const roomCodeEl = $("roomCode");
const scoreboardEl = $("scoreboard");
const top10El = $("top10");
const top10HintEl = $("top10Hint");

const boardEl = $("board");
const wasteEl = $("waste");
const deckCountEl = $("deckCount");
const drawBtn = $("drawBtn");
const comboEl = $("combo");
const scoreEl = $("score");
const gameMsg = $("gameMsg");
const restartBtn = $("restartBtn");

let currentRoom = null;
let isHost = false;
let roomState = null;

function xorshift32(seed) {
  let x = seed >>> 0;
  return () => {
    x ^= x << 13; x >>>= 0;
    x ^= x >>> 17; x >>>= 0;
    x ^= x << 5;  x >>>= 0;
    return (x >>> 0) / 4294967296;
  };
}

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = [ "A","2","3","4","5","6","7","8","9","10","J","Q","K" ];

function buildDeck(seed) {
  const rng = xorshift32(seed);
  const deck = [];
  for (let s = 0; s < 4; s++) for (let r = 1; r <= 13; r++) {
    deck.push({ r, s, label: `${RANKS[r-1]}${SUITS[s]}` });
  }
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function makeBoard(cards28) {
  const L0 = [0,1,2];
  const L1 = [3,4,5,6,7,8];
  const L2 = [9,10,11,12,13,14,15,16,17];
  const L3 = [18,19,20,21,22,23,24,25,26,27];

  const covers = new Map();
  covers.set(0, [3,4]); covers.set(1, [5,6]); covers.set(2, [7,8]);
  covers.set(3, [9,10]);  covers.set(4, [10,11]);
  covers.set(5, [12,13]); covers.set(6, [13,14]);
  covers.set(7, [15,16]); covers.set(8, [16,17]);
  covers.set(9,  [18,19]); covers.set(10, [19,20]); covers.set(11, [20,21]);
  covers.set(12, [21,22]); covers.set(13, [22,23]); covers.set(14, [23,24]);
  covers.set(15, [24,25]); covers.set(16, [25,26]); covers.set(17, [26,27]);

  const nodes = cards28.map((c, idx) => ({
    idx, card: c, removed: false, coveredBy: 0, covers: covers.get(idx) ?? []
  }));
  for (const [, bs] of covers.entries()) for (const b of bs) nodes[b].coveredBy += 1;
  return { nodes, levels: [L0, L1, L2, L3] };
}

let game = null;

function rankAdj(a, b) {
  if (a === 1 && b === 13) return true;
  if (a === 13 && b === 1) return true;
  return Math.abs(a - b) === 1;
}

function startLocalGame(seed) {
  const deck = buildDeck(seed);
  const boardCards = deck.slice(0, 28);
  const stock = deck.slice(28);
  const waste = stock.shift();
  const board = makeBoard(boardCards);

  game = { seed, board, stock, waste, score: 0, combo: 0, finished: false };
  updateUI();
  gameMsg.textContent = "Spiel läuft!";
  pushScore(false);
}

function canPlayNode(node) {
  if (node.removed) return false;
  if (node.coveredBy > 0) return false;
  return rankAdj(node.card.r, game.waste.r);
}

function removeNode(node) {
  node.removed = true;
  for (const bIdx of node.covers) {
    const below = game.board.nodes[bIdx];
    below.coveredBy = Math.max(0, below.coveredBy - 1);
  }
}

function remainingBoardCount() {
  return game.board.nodes.reduce((acc, n) => acc + (n.removed ? 0 : 1), 0);
}

function anyMovesAvailable() {
  return game.board.nodes.some(n => canPlayNode(n));
}

function checkWinLose() {
  if (remainingBoardCount() === 0) {
    game.finished = true;
    gameMsg.textContent = "🎉 Fertig! Alle Karten abgebaut.";
    pushScore(true);
    submitIfTop10();
    return;
  }
  if (!anyMovesAvailable() && game.stock.length === 0) {
    game.finished = true;
    gameMsg.textContent = "⛔ Keine Züge mehr. Deck leer.";
    pushScore(true);
    // Top-10 Check
    submitIfTop10();
  }
}

let latestTop10 = [];

function renderTop10(list) {
  latestTop10 = Array.isArray(list) ? list : [];
  if (!top10El) return;

  top10El.innerHTML = "";
  if (latestTop10.length === 0) {
    top10El.innerHTML = `<div class="scoreRow"><div class="name">Noch keine Einträge</div><div class="meta"></div></div>`;
    if (top10HintEl) top10HintEl.textContent = "";
    return;
  }

  latestTop10.forEach((r, i) => {
    const row = document.createElement("div");
    row.className = "scoreRow";

    const left = document.createElement("div");
    left.className = "name";
    left.textContent = `${i + 1}. ${r.name}`;

    const right = document.createElement("div");
    right.className = "meta";
    right.textContent = `${r.score}`;

    row.appendChild(left);
    row.appendChild(right);
    top10El.appendChild(row);
  });

  if (top10HintEl) top10HintEl.textContent = "Schaffst du es in die Top 10? Dann wird dein Name gespeichert.";
}

function qualifiesTop10(score) {
  if (!latestTop10 || latestTop10.length < 10) return true;
  const tenth = latestTop10[9]?.score ?? 0;
  return score > tenth;
}

function submitIfTop10() {
  if (!game) return;
  const s = game.score ?? 0;
  if (!qualifiesTop10(s)) return;

  // Name: nimm den Lobby-Namen, oder frag nochmal
  const defaultName = (nameEl?.value || "").trim() || "Player";
  const chosen = prompt("🎉 Top-10 möglich! Welcher Name soll in der Rangliste stehen?", defaultName);
  if (chosen == null) return;

  socket.emit("submit_leaderboard", { name: chosen, score: s });
}

function playNode(idx) {
  if (!game || game.finished) return;
  const node = game.board.nodes[idx];
  if (!canPlayNode(node)) return;

  game.combo += 1;
  game.score += 1 + Math.max(0, game.combo - 1);

  game.waste = node.card;
  removeNode(node);

  checkWinLose();
  updateUI();
  pushScore(false);
}

function drawCard() {
  if (!game || game.finished) return;
  if (game.stock.length === 0) { checkWinLose(); updateUI(); return; }
  game.waste = game.stock.shift();
  game.combo = 0;
  game.score = Math.max(0, game.score - 1);
  checkWinLose();
  updateUI();
  pushScore(false);
}

function pushScore(finished) {
  if (!currentRoom) return;
  socket.emit("score_update", { code: currentRoom, score: game?.score ?? 0, finished: !!finished });
}

function updateUI() {
  if (!game) return;
  wasteEl.textContent = game.waste.label;
  wasteEl.style.color = [1,2].includes(game.waste.s) ? "red" : "white";
  deckCountEl.textContent = String(game.stock.length);
  comboEl.textContent = String(game.combo);
  scoreEl.textContent = String(game.score);
  drawBtn.disabled = game.stock.length === 0 || game.finished;

  boardEl.innerHTML = "";
  for (const levelIdx of game.board.levels) {
    const level = document.createElement("div");
    level.className = "level";
    for (const idx of levelIdx) {
      const node = game.board.nodes[idx];
      const btn = document.createElement("button");
      btn.className = "cardBtn";
      btn.disabled = true;

      if (node.removed) {
        btn.textContent = "";
        btn.style.visibility = "hidden";
      } else {
        btn.textContent = node.card.label;
        const locked = node.coveredBy > 0;
        if (locked) btn.classList.add("locked");
        else {
          btn.style.color = [1,2].includes(node.card.s) ? "red" : "black";
          btn.style.background = "white";
        }
        const playable = !locked && rankAdj(node.card.r, game.waste.r);
        if (playable && !game.finished) {
          btn.classList.add("playable");
          btn.disabled = false;
          btn.onclick = () => playNode(idx);
        }
      }
      level.appendChild(btn);
    }
    boardEl.appendChild(level);
  }
}

function renderScoreboard(state) {
  scoreboardEl.innerHTML = "";
  for (const p of state.players) {
    const row = document.createElement("div");
    row.className = "scoreRow" + (p.id === socket.id ? " me" : "");
    const left = document.createElement("div");
    left.className = "name";
    left.textContent = p.name + (p.id === socket.id ? " (Du)" : "");

    const right = document.createElement("div");
    right.className = "meta";
    const fin = (p.finishedAtMs != null && state.startedAt != null)
      ? ` · ⏱ ${Math.max(0, Math.round((p.finishedAtMs - state.startedAt)/1000))}s`
      : "";
    right.textContent = `Score ${p.score}${fin}`;

    row.appendChild(left);
    row.appendChild(right);
    scoreboardEl.appendChild(row);
  }
}

function showLobby(msg="") {
  lobbyEl.classList.remove("hidden");
  roomEl.classList.add("hidden");
  lobbyMsg.textContent = msg;
  currentRoom = null; isHost = false; roomState = null; game = null;
}

function showRoom(code) {
  lobbyEl.classList.add("hidden");
  roomEl.classList.remove("hidden");
  roomCodeEl.textContent = code;
  roomMsg.textContent = "";
  gameMsg.textContent = "";
}

createBtn.onclick = () => socket.emit("create_room", { name: nameEl.value });
joinBtn.onclick = () => socket.emit("join_room", { code: codeEl.value, name: nameEl.value });

leaveBtn.onclick = () => {
  if (currentRoom) socket.emit("leave_room", { code: currentRoom });
  showLobby("Du hast den Room verlassen.");
};

startBtn.onclick = () => {
  if (currentRoom) socket.emit("start_game", { code: currentRoom });
};

drawBtn.onclick = () => drawCard();
restartBtn.onclick = () => { if (roomState?.seed) startLocalGame(roomState.seed); };

socket.on("error_msg", (msg) => {
  if (currentRoom) roomMsg.textContent = msg;
  else lobbyMsg.textContent = msg;
});

socket.on("joined_room", ({ code, isHost: host }) => {
  currentRoom = code; isHost = !!host;
  showRoom(code);
  startBtn.classList.toggle("hidden", !isHost);
  gameEl.classList.add("hidden");
});

socket.on("room_state", (state) => {
  roomState = state;
  renderScoreboard(state);

  startBtn.classList.toggle("hidden", !(isHost && state.status === "lobby"));
  if (state.status === "lobby") {
    roomMsg.textContent = "Warte auf Start durch Host.";
    gameEl.classList.add("hidden");
  } else {
    gameEl.classList.remove("hidden");
  }
});

socket.on("game_started", ({ seed }) => {
  roomMsg.textContent = `Spiel gestartet! (Seed ${seed})`;
  gameEl.classList.remove("hidden");
  startLocalGame(seed);
});

socket.on("top10", ({ top10 }) => {
  renderTop10(top10);
});

socket.on("submit_result", (res) => {
  if (!res?.ok) {
    if (res?.reason === "not_top10") alert("Nicht in Top 10 (oder nicht hoch genug).");
    else alert("Speichern fehlgeschlagen (DB).");
  } else {
    alert("✅ In Rangliste gespeichert!");
  }
});

showLobby("");
