import express from "express";
import http from "http";
import { Server } from "socket.io";
import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

function makeRoomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 5; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function sanitizeName(name) {
  const s = (name ?? "").toString().trim();
  // Erlaube Buchstaben/Zahlen/Leerzeichen/_- und begrenze Länge
  const cleaned = s.replace(/[^\p{L}\p{N} _-]/gu, "").slice(0, 18);
  return cleaned || "Player";
}

function clampInt(n, min, max) {
  const x = Number(n);
  if (!Number.isFinite(x)) return min;
  return Math.max(min, Math.min(max, Math.floor(x)));
}

// -------------------- SQLite Leaderboard --------------------
const db = new sqlite3.Database("./leaderboard.sqlite");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS leaderboard (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      score INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);
  db.run(`CREATE INDEX IF NOT EXISTS idx_score ON leaderboard(score DESC)`);
});

function getTop10() {
  return new Promise((resolve, reject) => {
    db.all(
      `SELECT name, score, created_at FROM leaderboard
       ORDER BY score DESC, created_at ASC
       LIMIT 10`,
      (err, rows) => (err ? reject(err) : resolve(rows))
    );
  });
}

function get10thScore() {
  return new Promise((resolve, reject) => {
    db.get(
      `SELECT score FROM leaderboard
       ORDER BY score DESC, created_at ASC
       LIMIT 1 OFFSET 9`,
      (err, row) => (err ? reject(err) : resolve(row?.score ?? null))
    );
  });
}

function insertScore(name, score) {
  return new Promise((resolve, reject) => {
    db.run(
      `INSERT INTO leaderboard (name, score, created_at) VALUES (?, ?, ?)`,
      [name, score, Date.now()],
      function (err) {
        if (err) reject(err);
        else resolve(this.lastID);
      }
    );
  });
}

async function broadcastTop10() {
  try {
    const top10 = await getTop10();
    io.emit("top10", { top10 });
  } catch (e) {
    // ignorieren
  }
}

// optional: REST endpoint (falls du mal ohne Socket testen willst)
app.get("/api/top10", async (_req, res) => {
  try {
    const top10 = await getTop10();
    res.json({ top10 });
  } catch {
    res.status(500).json({ error: "db_error" });
  }
});

// -------------------- Rooms --------------------
const rooms = new Map();

function publicRoomState(room) {
  const players = [];
  for (const [id, p] of room.players.entries()) {
    players.push({ id, name: p.name, score: p.score, finishedAtMs: p.finishedAtMs });
  }
  players.sort((a, b) => (b.score - a.score) || ((a.finishedAtMs ?? Infinity) - (b.finishedAtMs ?? Infinity)));
  return {
    code: room.code,
    seed: room.seed,
    status: room.status,
    startedAt: room.startedAt,
    players
  };
}

function emitRoom(room) {
  io.to(room.code).emit("room_state", publicRoomState(room));
}

io.on("connection", async (socket) => {
  // beim Connect direkt Top10 schicken
  try {
    socket.emit("top10", { top10: await getTop10() });
  } catch {}

  socket.on("create_room", ({ name }) => {
    const playerName = sanitizeName(name);

    let code;
    do code = makeRoomCode();
    while (rooms.has(code));

    const seed = Math.floor(Math.random() * 1_000_000_000);

    const room = {
      code,
      hostId: socket.id,
      seed,
      startedAt: null,
      status: "lobby",
      players: new Map()
    };

    room.players.set(socket.id, { name: playerName, score: 0, finishedAtMs: null });
    rooms.set(code, room);

    socket.join(code);
    socket.emit("joined_room", { code, isHost: true });
    emitRoom(room);
  });

  socket.on("join_room", ({ code, name }) => {
    const roomCode = (code ?? "").toString().trim().toUpperCase();
    const playerName = sanitizeName(name);

    const room = rooms.get(roomCode);
    if (!room) return socket.emit("error_msg", "Room nicht gefunden.");
    if (room.status !== "lobby") return socket.emit("error_msg", "Spiel läuft schon – neuen Room erstellen.");
    if (room.players.size >= 4) return socket.emit("error_msg", "Room ist voll (max. 4).");

    room.players.set(socket.id, { name: playerName, score: 0, finishedAtMs: null });
    socket.join(roomCode);
    socket.emit("joined_room", { code: roomCode, isHost: socket.id === room.hostId });
    emitRoom(room);
  });

  socket.on("start_game", ({ code }) => {
    const roomCode = (code ?? "").toString().trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!room) return;
    if (socket.id !== room.hostId) return socket.emit("error_msg", "Nur Host kann starten.");
    if (room.status !== "lobby") return;

    room.status = "started";
    room.startedAt = Date.now();
    for (const p of room.players.values()) {
      p.score = 0;
      p.finishedAtMs = null;
    }

    io.to(roomCode).emit("game_started", { seed: room.seed, startedAt: room.startedAt });
    emitRoom(room);
  });

  socket.on("score_update", ({ code, score, finished }) => {
    const roomCode = (code ?? "").toString().trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!room) return;
    const p = room.players.get(socket.id);
    if (!p) return;
    if (room.status !== "started") return;

    p.score = clampInt(score, 0, 9999999);

    if (finished && p.finishedAtMs == null) {
      p.finishedAtMs = Date.now();
      const allDone = [...room.players.values()].every(x => x.finishedAtMs != null);
      if (allDone) room.status = "finished";
    }

    emitRoom(room);
  });

  // Wird NUR am Ende gesendet, wenn Spieler Top10 versucht einzutragen
  socket.on("submit_leaderboard", async ({ name, score }) => {
    try {
      const n = sanitizeName(name);
      const s = clampInt(score, 0, 9999999);

      // nur eintragen, wenn Top10 möglich ist
      const tenth = await get10thScore();
      const qualifies = tenth == null || s > tenth;

      if (!qualifies) {
        socket.emit("submit_result", { ok: false, reason: "not_top10" });
        return;
      }

      await insertScore(n, s);

      // auf Top10 trimmen (optional: keep history; wenn du wirklich nur 10 speichern willst, sag Bescheid)
      // Wir lassen History drin und zeigen nur Top10 an.

      socket.emit("submit_result", { ok: true });
      await broadcastTop10();
    } catch {
      socket.emit("submit_result", { ok: false, reason: "db_error" });
    }
  });

  socket.on("leave_room", ({ code }) => {
    const roomCode = (code ?? "").toString().trim().toUpperCase();
    const room = rooms.get(roomCode);
    if (!room) return;

    room.players.delete(socket.id);
    socket.leave(roomCode);

    if (room.hostId === socket.id) room.hostId = room.players.keys().next().value ?? null;
    if (room.players.size === 0) rooms.delete(roomCode);
    else emitRoom(room);
  });

  socket.on("disconnect", () => {
    for (const room of rooms.values()) {
      if (room.players.has(socket.id)) {
        room.players.delete(socket.id);
        if (room.hostId === socket.id) room.hostId = room.players.keys().next().value ?? null;
        emitRoom(room);
      }
    }
    for (const [code, room] of rooms.entries()) {
      if (room.players.size === 0) rooms.delete(code);
    }
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, "0.0.0.0", () => console.log("Server läuft auf Port", PORT));
