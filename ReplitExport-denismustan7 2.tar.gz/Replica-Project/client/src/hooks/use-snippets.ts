import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type SnippetInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSnippets() {
  const { toast } = useToast();

  return useQuery({
    queryKey: [api.snippets.list.path],
    queryFn: async () => {
      const res = await fetch(api.snippets.list.path, { credentials: "include" });
      if (!res.ok) {
        toast({ variant: "destructive", title: "Failed to fetch snippets" });
        throw new Error("Failed to fetch snippets");
      }
      return api.snippets.list.responses[200].parse(await res.json());
    },
  });
}

export function useSnippet(id: number | null) {
  const { toast } = useToast();
  
  return useQuery({
    queryKey: [api.snippets.get.path, id],
    enabled: !!id,
    queryFn: async () => {
      if (!id) return null;
      const url = buildUrl(api.snippets.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) {
        toast({ variant: "destructive", title: "Failed to fetch snippet" });
        throw new Error("Failed to fetch");
      }
      return api.snippets.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreateSnippet() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: SnippetInput) => {
      const res = await fetch(api.snippets.create.path, {
        method: api.snippets.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create snippet");
      }
      return api.snippets.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
      toast({ title: "Snippet saved", description: "Your code snippet has been created." });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    }
  });
}

export function useUpdateSnippet() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<SnippetInput>) => {
      const url = buildUrl(api.snippets.update.path, { id });
      const res = await fetch(url, {
        method: api.snippets.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error("Failed to update snippet");
      }
      return api.snippets.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.snippets.get.path, data.id] });
      toast({ title: "Snippet updated", description: "Changes saved successfully." });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    }
  });
}

export function useDeleteSnippet() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.snippets.delete.path, { id });
      const res = await fetch(url, { 
        method: api.snippets.delete.method,
        credentials: "include" 
      });
      
      if (!res.ok) throw new Error("Failed to delete snippet");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.snippets.list.path] });
      toast({ title: "Snippet deleted", description: "The snippet has been permanently removed." });
    },
    onError: (err) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    }
  });
}
