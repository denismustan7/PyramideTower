import { Terminal, Trash2 } from "lucide-react";
import { useRef, useEffect } from "react";

export type LogMessage = {
  type: "log" | "error" | "warn" | "info";
  content: string;
  timestamp: number;
};

interface ConsoleProps {
  logs: LogMessage[];
  onClear: () => void;
}

export function Console({ logs, onClear }: ConsoleProps) {
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-card border-t border-border">
      <div className="flex items-center justify-between px-4 py-2 bg-background border-b border-border">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Terminal className="w-4 h-4" />
          <span className="text-xs font-semibold uppercase tracking-wider">Console</span>
        </div>
        <button 
          onClick={onClear}
          className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded-md transition-colors"
          title="Clear Console"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 font-mono text-sm space-y-2">
        {logs.length === 0 ? (
          <div className="text-muted-foreground/50 italic text-xs">Console output will appear here...</div>
        ) : (
          logs.map((log, index) => (
            <div 
              key={log.timestamp + index} 
              className={`flex gap-3 animate-in fade-in slide-in-from-bottom-1 duration-200 border-l-2 pl-2 ${
                log.type === 'error' ? 'border-destructive text-destructive' :
                log.type === 'warn' ? 'border-yellow-500 text-yellow-500' :
                'border-transparent text-foreground'
              }`}
            >
              <span className="text-muted-foreground select-none shrink-0 opacity-50 text-[10px] pt-1">
                {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit' })}
              </span>
              <pre className="whitespace-pre-wrap break-all font-mono">
                {log.content}
              </pre>
            </div>
          ))
        )}
        <div ref={endRef} />
      </div>
    </div>
  );
}
