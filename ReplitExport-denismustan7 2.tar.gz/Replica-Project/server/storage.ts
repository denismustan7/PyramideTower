import { db } from "./db";
import { snippets, type InsertSnippet } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getSnippets(): Promise<typeof snippets.$inferSelect[]>;
  getSnippet(id: number): Promise<typeof snippets.$inferSelect | undefined>;
  createSnippet(snippet: InsertSnippet): Promise<typeof snippets.$inferSelect>;
  updateSnippet(id: number, snippet: Partial<InsertSnippet>): Promise<typeof snippets.$inferSelect | undefined>;
  deleteSnippet(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getSnippets() {
    return await db.select().from(snippets).orderBy(desc(snippets.createdAt));
  }
  async getSnippet(id: number) {
    const [snippet] = await db.select().from(snippets).where(eq(snippets.id, id));
    return snippet;
  }
  async createSnippet(insertSnippet: InsertSnippet) {
    const [snippet] = await db.insert(snippets).values(insertSnippet).returning();
    return snippet;
  }
  async updateSnippet(id: number, update: Partial<InsertSnippet>) {
    const [snippet] = await db.update(snippets).set(update).where(eq(snippets.id, id)).returning();
    return snippet;
  }
  async deleteSnippet(id: number) {
    await db.delete(snippets).where(eq(snippets.id, id));
  }
}

export const storage = new DatabaseStorage();
