import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Database table for leaderboard
export const leaderboard = pgTable("leaderboard", {
  id: serial("id").primaryKey(),
  playerName: text("player_name").notNull(),
  score: integer("score").notNull(),
  rank: text("rank").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format for daily grouping
});

export const insertLeaderboardSchema = createInsertSchema(leaderboard).omit({ id: true });
export type InsertLeaderboard = z.infer<typeof insertLeaderboardSchema>;
export type LeaderboardEntry = typeof leaderboard.$inferSelect;

// Card suits and values
export type Suit = 'hearts' | 'diamonds' | 'clubs' | 'spades';
export type CardValue = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';

export interface Card {
  id: string;
  suit: Suit;
  value: CardValue;
  isFaceUp: boolean;
  isPlayable: boolean; // Can be clicked (not covered by other cards)
}

// Pyramid node represents a card position in a tower
export interface PyramidNode {
  card: Card | null; // null if card was removed
  tower: number; // 0, 1, or 2 - which tower this card belongs to
  row: number; // 0 = top/back (1 card), 3 = front/bottom (4 cards)
  col: number; // column position within the row
  coveredBy: string[]; // IDs of cards that must be removed before this card is playable
  isDimmed: boolean; // True if card is visible but still locked (covered by at least one card)
}

// Bonus slot state
export interface BonusSlotState {
  card: Card | null; // Card currently on the slot
  isActive: boolean; // Whether the slot is unlocked
}

// Game state
export interface GameState {
  pyramid: PyramidNode[]; // All cards from all towers (flattened array)
  towers: PyramidNode[][]; // Cards organized by tower [tower0, tower1, tower2]
  drawPile: Card[]; // Face-down draw pile (21 cards)
  discardPile: Card[]; // Face-up discard pile (top is current)
  bonusSlot1: BonusSlotState; // Unlocked at 4 combo
  bonusSlot2: BonusSlotState; // Unlocked at 7 combo
  bonusSlot1ActivationCount: number; // How many times slot 1 has been activated (for deterministic generation)
  bonusSlot2ActivationCount: number; // How many times slot 2 has been activated
  gameSeed: number; // Seed for deterministic random generation
  score: number;
  combo: number; // Current combo multiplier
  maxCombo: number; // Highest combo achieved this game
  level: number;
  timeRemaining: number; // Seconds
  totalTime: number; // Total time for this level
  towersCleared: number; // 0-3
  phase: 'playing' | 'paused' | 'won' | 'lost';
  cardsRemaining: number; // Cards still on pyramids
}

// Score breakdown for game over screen
export interface ScoreBreakdown {
  baseScore: number;
  comboBonus: number;
  towerBonus: number;
  timeBonus: number;
  perfectBonus: number;
  totalScore: number;
}

// Rank thresholds
export const RANK_THRESHOLDS = {
  NOVIZE: 0,
  ZAUBERLEHRLING: 10001,
  MAGIER: 30001,
  ERZMAGIER: 70001,
  TURMWAECHTER: 150001,
} as const;

export type RankName = 'Novize' | 'Zauberlehrling' | 'Magier' | 'Erzmagier' | 'Turmwächter';

export function getRank(totalScore: number): RankName {
  if (totalScore >= RANK_THRESHOLDS.TURMWAECHTER) return 'Turmwächter';
  if (totalScore >= RANK_THRESHOLDS.ERZMAGIER) return 'Erzmagier';
  if (totalScore >= RANK_THRESHOLDS.MAGIER) return 'Magier';
  if (totalScore >= RANK_THRESHOLDS.ZAUBERLEHRLING) return 'Zauberlehrling';
  return 'Novize';
}

// Card value sequence for +1/-1 matching
export const CARD_VALUES: CardValue[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

export function getValueIndex(value: CardValue): number {
  return CARD_VALUES.indexOf(value);
}

// Check if card can be played on discard pile (±1 with Ace wrap)
export function canPlayCard(cardValue: CardValue, discardTopValue: CardValue): boolean {
  const cardIdx = getValueIndex(cardValue);
  const discardIdx = getValueIndex(discardTopValue);
  
  // Normal +1/-1
  if (Math.abs(cardIdx - discardIdx) === 1) return true;
  
  // Ace wraps: A can go on K, K can go on A
  if ((cardValue === 'A' && discardTopValue === 'K') ||
      (cardValue === 'K' && discardTopValue === 'A')) {
    return true;
  }
  
  return false;
}

// Game constants - Tri-Peaks structure (3 small towers)
// Each tower has 4 rows: 1, 2, 3, 4 cards = 10 cards per tower
// Row 0 = back/top (1 card), Row 3 = front/bottom (4 cards)
export const TOWER_ROWS = [1, 2, 3, 4]; // Cards per row in each tower (back to front)
export const CARDS_PER_TOWER = 10; // 1+2+3+4 = 10 cards per tower
export const NUM_TOWERS = 3;
export const TOTAL_TABLEAU_CARDS = 30; // 3 towers × 10 cards = 30 cards
export const DRAW_PILE_SIZE = 23; // 23 cards in draw pile

// Legacy constants for backwards compatibility
export const PYRAMID_ROWS = TOWER_ROWS;
export const TOTAL_PYRAMID_CARDS = TOTAL_TABLEAU_CARDS;
export const BASE_POINTS = 100;
export const TOWER_BONUS = 500;
export const PERFECT_BONUS = 5000;
export const DECK_BONUS_PER_CARD = 500; // 500 points per remaining draw pile card when level completed
export const INVALID_MOVE_PENALTY = 200; // Points deducted for clicking playable card that doesn't fit
export const TIME_BONUS_MULTIPLIER = 10;
export const BASE_TIME = 60; // 60 seconds base time
export const TIME_DECREASE_START_ROUND = 5; // Timer starts decreasing from round 5
export const TIME_DECREASE_PER_LEVEL = 5; // 5 seconds less per round starting from round 5
export const BONUS_SLOT_1_COMBO = 4; // Combo needed to unlock slot 1
export const BONUS_SLOT_2_COMBO = 7; // Combo needed to unlock slot 2

// Multiplayer configuration based on player count
export const MULTIPLAYER_CONFIG = {
  4: {
    totalRounds: 8,
    baseTimeRounds: 4, // Rounds 1-4 have 60 seconds
    timeDecreaseStartRound: 5,
    eliminationStartRound: 5,
    timeDecreasePerRound: 3
  },
  5: {
    totalRounds: 9,
    baseTimeRounds: 5,
    timeDecreaseStartRound: 6,
    eliminationStartRound: 6,
    timeDecreasePerRound: 3
  },
  6: {
    totalRounds: 10,
    baseTimeRounds: 6, // Rounds 1-6 have 60 seconds
    timeDecreaseStartRound: 7,
    eliminationStartRound: 7,
    timeDecreasePerRound: 3
  }
} as const;

export function getMultiplayerConfig(playerCount: number) {
  if (playerCount <= 4) return MULTIPLAYER_CONFIG[4];
  if (playerCount === 5) return MULTIPLAYER_CONFIG[5];
  return MULTIPLAYER_CONFIG[6];
}

export function getRoundTime(round: number, playerCount: number): number {
  const config = getMultiplayerConfig(playerCount);
  if (round <= config.baseTimeRounds) return BASE_TIME;
  const decreaseRounds = round - config.baseTimeRounds;
  return Math.max(30, BASE_TIME - (decreaseRounds * config.timeDecreasePerRound));
}

// Multiplayer types
export interface MultiplayerPlayer {
  id: string;
  name: string;
  score: number; // Round score
  totalScore: number; // Cumulative score across all rounds
  cardsRemaining: number;
  isReady: boolean;
  isHost: boolean;
  finished: boolean;
  isEliminated: boolean;
  eliminatedInRound: number | null;
}

export interface MultiplayerRoom {
  code: string;
  players: MultiplayerPlayer[];
  gameSeed: number | null;
  status: 'waiting' | 'playing' | 'round_end' | 'finished';
  maxPlayers: number;
  createdAt: number;
  currentRound: number;
  totalRounds: number;
  roundTimeLimit: number;
}

export interface MultiplayerGameState extends GameState {
  roomCode: string;
  playerId: string;
  opponents: MultiplayerPlayer[];
  currentRound: number;
  totalRounds: number;
  isSpectating: boolean;
  spectatingPlayerId: string | null;
}

// WebSocket message types
export type WSMessageType = 
  | 'create_room'
  | 'join_room'
  | 'leave_room'
  | 'set_ready'
  | 'start_game'
  | 'start_round'
  | 'game_update'
  | 'round_end'
  | 'player_eliminated'
  | 'player_finished'
  | 'room_update'
  | 'spectate_player'
  | 'spectator_update'
  | 'error';

export interface WSMessage {
  type: WSMessageType;
  payload?: any;
}
