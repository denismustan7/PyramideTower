import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Card, Suit } from "@shared/schema";

interface PlayingCardProps {
  card: Card;
  isPlayable?: boolean;
  isCovered?: boolean;
  isShaking?: boolean;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

const suitSymbols: Record<Suit, string> = {
  hearts: '\u2665',
  diamonds: '\u2666',
  clubs: '\u2663',
  spades: '\u2660',
};

const suitColors: Record<Suit, { text: string; fill: string }> = {
  hearts: { text: '#dc2626', fill: '#dc2626' },
  diamonds: { text: '#dc2626', fill: '#dc2626' },
  clubs: { text: '#1f2937', fill: '#1f2937' },
  spades: { text: '#1f2937', fill: '#1f2937' },
};

const sizeClasses = {
  sm: 'w-13 h-[78px]',
  md: 'w-14 h-[84px] sm:w-16 sm:h-24',
  lg: 'w-16 h-24 sm:w-20 sm:h-28',
};

const cornerSizes = {
  sm: { rank: 'text-[10px]', suit: 'text-[8px]' },
  md: { rank: 'text-xs sm:text-sm', suit: 'text-[10px] sm:text-xs' },
  lg: { rank: 'text-sm sm:text-base', suit: 'text-xs sm:text-sm' },
};

const centerRankSizes = {
  sm: 'text-[2rem]',
  md: 'text-[2.5rem] sm:text-[3rem]',
  lg: 'text-[3rem] sm:text-[3.5rem]',
};

function CardBack({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  return (
    <div 
      className={cn(
        sizeClasses[size],
        "rounded-lg relative overflow-hidden"
      )}
      style={{
        background: '#FFFFFF',
        border: '1px solid #d1d5db',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}
    >
      <div 
        className="absolute inset-[3px] rounded-md overflow-hidden"
        style={{
          background: '#dc2626',
        }}
      >
        <div 
          className="absolute inset-0"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 3px,
                rgba(255,255,255,0.15) 3px,
                rgba(255,255,255,0.15) 4px
              ),
              repeating-linear-gradient(
                -45deg,
                transparent,
                transparent 3px,
                rgba(255,255,255,0.15) 3px,
                rgba(255,255,255,0.15) 4px
              )
            `
          }}
        />
        <div 
          className="absolute inset-1 rounded-sm"
          style={{ border: '1px solid rgba(255,255,255,0.3)' }}
        />
      </div>
    </div>
  );
}


export function PlayingCard({ 
  card, 
  isPlayable = false, 
  isCovered = false,
  isShaking = false,
  onClick,
  size = 'md'
}: PlayingCardProps) {
  
  if (!card.isFaceUp) {
    return <CardBack size={size} />;
  }

  const colors = suitColors[card.suit];

  return (
    <motion.button
      className={cn(
        sizeClasses[size],
        "rounded-lg flex flex-col relative overflow-hidden",
        "transition-all duration-150",
        isPlayable && !isCovered ? "cursor-pointer" : "cursor-default",
        isCovered && "brightness-75",
      )}
      style={{
        background: '#FFFFFF',
        border: '1px solid #d1d5db',
        boxShadow: isCovered 
          ? '0 1px 2px rgba(0,0,0,0.1)' 
          : '0 2px 8px rgba(0,0,0,0.15)',
      }}
      onClick={isPlayable && !isCovered ? onClick : undefined}
      animate={isShaking ? {
        x: [0, -5, 5, -5, 5, 0],
        transition: { duration: 0.3 }
      } : {}}
      whileHover={isPlayable && !isCovered ? { 
        scale: 1.08, 
        y: -4,
        boxShadow: '0 6px 16px rgba(0,0,0,0.2)'
      } : {}}
      whileTap={isPlayable && !isCovered ? { scale: 0.95 } : {}}
      data-testid={`card-${card.id}`}
    >
      {/* Top-left corner */}
      <div className="absolute top-0.5 left-1 flex flex-col items-center leading-none">
        <span 
          className={cn("font-bold", cornerSizes[size].rank)}
          style={{ color: colors.text }}
        >
          {card.value}
        </span>
        <span 
          className={cornerSizes[size].suit}
          style={{ color: colors.text }}
        >
          {suitSymbols[card.suit]}
        </span>
      </div>

      {/* Bottom-right corner (inverted) */}
      <div className="absolute bottom-0.5 right-1 flex flex-col items-center leading-none rotate-180">
        <span 
          className={cn("font-bold", cornerSizes[size].rank)}
          style={{ color: colors.text }}
        >
          {card.value}
        </span>
        <span 
          className={cornerSizes[size].suit}
          style={{ color: colors.text }}
        >
          {suitSymbols[card.suit]}
        </span>
      </div>

      {/* Center content - large rank */}
      <div className="flex-1 flex items-center justify-center">
        <span 
          className={cn("font-bold", centerRankSizes[size])}
          style={{ color: colors.text }}
        >
          {card.value}
        </span>
      </div>
    </motion.button>
  );
}

interface BonusSlotProps {
  card: Card | null;
  isActive: boolean;
  slotNumber: 1 | 2;
  hasSelectedCard?: boolean;
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

const slotSizeClasses = {
  sm: { width: 52, height: 78 },
  md: { width: 56, height: 84 },
  lg: { width: 64, height: 96 },
};

export function BonusSlot({ card, isActive, slotNumber, hasSelectedCard, onClick, size = 'md' }: BonusSlotProps) {
  const dimensions = slotSizeClasses[size];
  
  if (!isActive) {
    return (
      <div 
        className="rounded-lg"
        style={{
          width: dimensions.width,
          height: dimensions.height,
          background: 'rgba(0, 0, 0, 0.4)',
          border: '2px solid rgba(100, 100, 100, 0.4)',
          minWidth: 40,
          minHeight: 44,
        }}
      />
    );
  }

  if (card) {
    return (
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3 }}
        data-testid={`bonus-slot-${slotNumber}`}
      >
        <PlayingCard
          card={card}
          isPlayable={false}
          isCovered={false}
          size={size}
        />
      </motion.div>
    );
  }

  return (
    <motion.div 
      className="rounded-lg"
      style={{
        width: dimensions.width,
        height: dimensions.height,
        background: 'rgba(212, 175, 55, 0.1)',
        border: '2px dashed #D4AF37',
        boxShadow: '0 0 15px rgba(212, 175, 55, 0.3)',
        minWidth: 40,
        minHeight: 44,
      }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ 
        opacity: 1, 
        scale: 1,
        boxShadow: ['0 0 15px rgba(212, 175, 55, 0.3)', '0 0 25px rgba(212, 175, 55, 0.5)', '0 0 15px rgba(212, 175, 55, 0.3)']
      }}
      transition={{ 
        duration: 0.3,
        boxShadow: { duration: 1.5, repeat: Infinity }
      }}
      data-testid={`bonus-slot-${slotNumber}`}
    />
  );
}
