import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useLocation } from "wouter";

// GET /api/lobbies
export function useLobbies() {
  return useQuery({
    queryKey: [api.lobbies.list.path],
    queryFn: async () => {
      const res = await fetch(api.lobbies.list.path);
      if (!res.ok) throw new Error("Failed to fetch lobbies");
      return api.lobbies.list.responses[200].parse(await res.json());
    },
    refetchInterval: 3000, // Poll every 3s for live updates
  });
}

// POST /api/lobbies
export function useCreateLobby() {
  const [, setLocation] = useLocation();
  
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.lobbies.create.path, {
        method: api.lobbies.create.method,
      });
      if (!res.ok) throw new Error("Failed to create lobby");
      return api.lobbies.create.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      setLocation(`/game/${data.roomId}`);
    },
  });
}
