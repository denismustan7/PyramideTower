import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useLobbies, useCreateLobby } from "@/hooks/use-lobbies";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Users, Plus, PlayCircle, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Home() {
  const { data: lobbies, isLoading } = useLobbies();
  const createLobby = useCreateLobby();
  const [hoveredLobby, setHoveredLobby] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[hsl(var(--background))] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-10 left-10 w-32 h-48 border-4 border-white rounded-xl transform -rotate-12" />
        <div className="absolute bottom-20 right-20 w-32 h-48 border-4 border-white rounded-xl transform rotate-6" />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 border-4 border-red-400 rounded-full opacity-50" />
      </div>

      <motion.div 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="z-10 text-center mb-12"
      >
        <div className="inline-flex items-center justify-center p-3 mb-4 bg-white/10 rounded-full backdrop-blur-sm border border-white/20 shadow-xl">
          <Trophy className="w-6 h-6 text-yellow-400 mr-2" />
          <span className="text-white font-bold tracking-wide">MULTIPLAYER EDITION</span>
        </div>
        <h1 className="text-6xl md:text-8xl font-display text-white mb-2 drop-shadow-lg tracking-wider">
          Tri-Peaks
        </h1>
        <p className="text-xl text-green-100 font-medium tracking-wide">
          Challenge friends to a card clearing frenzy!
        </p>
      </motion.div>

      <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-8 z-10">
        
        {/* Create Game Section */}
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="h-full bg-white/95 backdrop-blur shadow-2xl border-0 overflow-hidden group hover:scale-[1.02] transition-transform duration-300">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-yellow-400 to-orange-500" />
            <CardContent className="flex flex-col items-center justify-center h-[300px] p-8 text-center space-y-6">
              <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <Plus className="w-10 h-10 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">New Game</h2>
                <p className="text-slate-500">Create a new room and invite your friends</p>
              </div>
              <Button 
                size="lg" 
                className="w-full rounded-xl h-14 text-lg font-bold shadow-lg shadow-primary/20"
                disabled={createLobby.isPending}
                onClick={() => createLobby.mutate()}
              >
                {createLobby.isPending ? "Creating..." : "Create Room"}
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Join Game Section */}
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="h-full bg-slate-900/90 text-white backdrop-blur border-0 overflow-hidden shadow-2xl">
            <div className="p-6 border-b border-white/10 flex justify-between items-center">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Users className="w-5 h-5 text-green-400" />
                Active Lobbies
              </h2>
              <span className="text-xs font-mono bg-white/10 px-2 py-1 rounded">
                {lobbies?.length || 0} ONLINE
              </span>
            </div>
            
            <ScrollArea className="h-[220px]">
              {isLoading ? (
                <div className="flex items-center justify-center h-full text-white/50">
                  Loading lobbies...
                </div>
              ) : lobbies && lobbies.length > 0 ? (
                <div className="p-4 space-y-2">
                  {lobbies.map((lobby) => (
                    <Link key={lobby.roomId} href={`/game/${lobby.roomId}`} className="block">
                      <div 
                        className={cn(
                          "group flex items-center justify-between p-4 rounded-xl transition-all duration-200 cursor-pointer border",
                          hoveredLobby === lobby.roomId
                            ? "bg-green-600 border-green-400 translate-x-1"
                            : "bg-white/5 border-white/10 hover:bg-white/10"
                        )}
                        onMouseEnter={() => setHoveredLobby(lobby.roomId)}
                        onMouseLeave={() => setHoveredLobby(null)}
                      >
                        <div>
                          <p className="font-mono font-bold text-lg">{lobby.roomId}</p>
                          <p className="text-xs text-white/50 uppercase tracking-wider">{lobby.status}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <span className="text-sm font-bold block">{lobby.playerCount} Players</span>
                            <span className="text-xs text-white/50">Waiting...</span>
                          </div>
                          <PlayCircle className={cn(
                            "w-8 h-8 transition-all duration-300",
                            hoveredLobby === lobby.roomId ? "text-white scale-110" : "text-white/20"
                          )} />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-white/30 p-8 text-center">
                  <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-3">
                    <LogOut className="w-6 h-6 opacity-50 rotate-180" />
                  </div>
                  <p>No active games found.</p>
                  <p className="text-sm mt-1">Be the first to create one!</p>
                </div>
              )}
            </ScrollArea>
          </Card>
        </motion.div>
      </div>
      
      {/* Footer */}
      <footer className="absolute bottom-4 text-white/30 text-sm font-medium">
        Tri-Peaks Multiplayer • Built with React & Tailwind
      </footer>
    </div>
  );
}
