import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Card } from "@shared/schema";
import { Heart, Diamond, Club, Spade } from "lucide-react";

interface PlayingCardProps {
  card: Card;
  index?: number;
  onClick?: () => void;
  disabled?: boolean;
  isPlayable?: boolean;
  className?: string;
}

const SuitIcon = ({ suit, className }: { suit: string; className?: string }) => {
  switch (suit) {
    case 'H': return <Heart className={cn("fill-current", className)} />;
    case 'D': return <Diamond className={cn("fill-current", className)} />;
    case 'C': return <Club className={cn("fill-current", className)} />;
    case 'S': return <Spade className={cn("fill-current", className)} />;
    default: return null;
  }
};

export function PlayingCard({ 
  card, 
  index = 0, 
  onClick, 
  disabled, 
  isPlayable,
  className 
}: PlayingCardProps) {
  const isRed = card.suit === 'H' || card.suit === 'D';
  
  // Back of card
  if (!card.faceUp) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: index * 0.05 }}
        className={cn(
          "relative w-16 h-24 sm:w-20 sm:h-28 rounded-lg card-shadow border-2 border-white",
          "bg-blue-600 overflow-hidden",
          className
        )}
      >
        <div className="absolute inset-1 border border-blue-400 rounded opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center opacity-20">
           <div className="w-12 h-12 rounded-full border-4 border-white" />
        </div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500/20 to-transparent" />
      </motion.div>
    );
  }

  // Front of card
  return (
    <motion.button
      layoutId={isPlayable ? `playable-${card.suit}-${card.rank}` : undefined}
      initial={{ scale: 0.8, y: -20, opacity: 0 }}
      animate={{ scale: 1, y: 0, opacity: 1 }}
      whileHover={!disabled && onClick ? { y: -8, scale: 1.05 } : {}}
      whileTap={!disabled && onClick ? { scale: 0.95 } : {}}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className={cn(
        "relative w-16 h-24 sm:w-20 sm:h-28 rounded-lg bg-white card-shadow select-none",
        "flex flex-col justify-between p-1.5 sm:p-2",
        "transition-colors duration-200",
        isRed ? "text-red-600" : "text-slate-900",
        disabled && "opacity-80 cursor-default",
        isPlayable && "ring-4 ring-yellow-400 ring-offset-2 ring-offset-green-800 cursor-pointer z-10",
        className
      )}
    >
      {/* Top Left Rank */}
      <div className="text-left leading-none flex flex-col items-center w-4">
        <span className="text-sm sm:text-lg font-bold font-sans tracking-tighter">{card.rank}</span>
        <SuitIcon suit={card.suit} className="w-2.5 h-2.5 sm:w-3 sm:h-3 mt-0.5" />
      </div>

      {/* Center Suit */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <SuitIcon suit={card.suit} className="w-8 h-8 sm:w-10 sm:h-10 opacity-20" />
      </div>

      {/* Bottom Right Rank (Rotated) */}
      <div className="text-left leading-none flex flex-col items-center w-4 self-end rotate-180">
        <span className="text-sm sm:text-lg font-bold font-sans tracking-tighter">{card.rank}</span>
        <SuitIcon suit={card.suit} className="w-2.5 h-2.5 sm:w-3 sm:h-3 mt-0.5" />
      </div>
      
      {/* Glossy overlay effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/40 to-transparent rounded-lg pointer-events-none" />
    </motion.button>
  );
}
