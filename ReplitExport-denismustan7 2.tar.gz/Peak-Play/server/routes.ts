import type { Express } from "express";
import type { Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { nanoid } from "nanoid";
import { WS_EVENTS } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.lobbies.create.path, async (_req, res) => {
    const roomId = nanoid(6).toUpperCase();
    await storage.createGame(roomId);
    storage.createGameState(roomId);
    res.status(201).json({ roomId });
  });

  app.get(api.lobbies.list.path, (_req, res) => {
    const rooms = storage.getAllActiveRooms();
    const listing = rooms.map(r => ({
      roomId: r.roomId,
      playerCount: r.players.filter(p => p.isConnected).length,
      status: r.status
    }));
    res.json(listing);
  });

  const io = new SocketIOServer(httpServer, {
    path: "/socket.io",
    cors: {
      origin: "*",
    }
  });

  io.on("connection", (socket) => {
    let currentRoomId: string | null = null;
    let playerId: string | null = null;

    socket.on(WS_EVENTS.JOIN_ROOM, (payload) => {
      const { roomId, playerName } = payload;
      currentRoomId = roomId;
      playerId = playerName;

      socket.join(roomId);
      
      let state = storage.getGameState(roomId);
      if (!state) state = storage.createGameState(roomId);

      storage.addPlayer(roomId, {
        id: playerId,
        name: playerName,
        score: 0,
        progress: 0,
        isConnected: true
      });

      io.to(roomId).emit(WS_EVENTS.GAME_STATE, storage.getGameState(roomId));
    });

    socket.on(WS_EVENTS.START_GAME, (payload) => {
      const { roomId } = payload;
      storage.updateGameStatus(roomId, 'playing');
      io.to(roomId).emit(WS_EVENTS.GAME_STATE, storage.getGameState(roomId));
    });

    socket.on(WS_EVENTS.UPDATE_SCORE, (payload) => {
      const { roomId, score, progress } = payload;
      if (playerId) {
        storage.updatePlayer(roomId, playerId, { score, progress });
        io.to(roomId).emit(WS_EVENTS.GAME_STATE, storage.getGameState(roomId));
      }
    });

    socket.on("disconnect", () => {
      if (currentRoomId && playerId) {
        storage.removePlayer(currentRoomId, playerId);
        io.to(currentRoomId).emit(WS_EVENTS.GAME_STATE, storage.getGameState(currentRoomId));
      }
    });
  });

  return httpServer;
}
